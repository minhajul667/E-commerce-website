<?php 

$connect = mysqli_connect("localhost:3307","root","","ecomme");

